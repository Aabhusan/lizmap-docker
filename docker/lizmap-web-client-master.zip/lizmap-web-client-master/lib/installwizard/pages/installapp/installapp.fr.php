<?php

$locales = array(

    'title'=>'Installation de l\'application',

    'install.start'=>'Démarrage de l\'installation..',
    'install.end'=>'Fin',
    
    'installation.ok'=>'L\'installation est un succès',
    'installation.cancelled'=>'L\'installation a échoué. Corrigez les erreurs et rechargez cette page.',

);
