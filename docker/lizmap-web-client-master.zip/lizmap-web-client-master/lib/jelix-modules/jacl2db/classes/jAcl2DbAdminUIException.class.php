<?php
/**
 * @package     jelix_modules
 * @subpackage  jacl2db
 * @author      Laurent Jouanneau
 * @copyright   2017 Laurent Jouanneau
 * @link        http://jelix.org
 * @licence     http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public Licence, see LICENCE file
 */


class jAcl2DbAdminUIException extends Exception {

}