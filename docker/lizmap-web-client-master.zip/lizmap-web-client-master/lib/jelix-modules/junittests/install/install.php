<?php
/**
* @package     jelix
* @subpackage  junittests module
* @author      Laurent Jouanneau
* @contributor
* @copyright   2009 Laurent Jouanneau
* @link        http://www.jelix.org
* @licence     GNU Lesser General Public Licence see LICENCE file or http://www.gnu.org/licenses/lgpl.html
*/


class junittestsModuleInstaller extends jInstallerModule {

    function install() {

    }
}