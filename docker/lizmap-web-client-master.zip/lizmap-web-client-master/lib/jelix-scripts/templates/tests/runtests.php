<?php

require(__DIR__.'/../application.init.php');

//require_once 'PHPUnit/Autoload.php';

require(LIB_PATH.'jelix-tests/phpunit.inc.php');
